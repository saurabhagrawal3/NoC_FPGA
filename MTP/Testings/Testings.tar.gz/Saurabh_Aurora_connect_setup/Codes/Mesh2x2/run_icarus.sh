#!/bin/bash
iverilog *.v
./a.out
